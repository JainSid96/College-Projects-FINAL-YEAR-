/*
SQLyog Community Edition- MySQL GUI v7.15 
MySQL - 5.5.29 : Database - examinvigilation
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`examinvigilation` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `examinvigilation`;

/*Table structure for table `faculty` */

DROP TABLE IF EXISTS `faculty`;

CREATE TABLE `faculty` (
  `facultyname` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `empid` varchar(100) DEFAULT NULL,
  `roomno` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `faculty` */

insert  into `faculty`(`facultyname`,`password`,`email`,`department`,`empid`,`roomno`,`status`) values ('nikil','nikil','nikilp306@gmail.com','CSE','123','105','No'),('dileep','dileep','dileep@gmail.com','ECE','234','101','No'),('aa','aa','aa@gmail.com','IT','878','','No'),('praneeth','praneeth','praneeth@gmail.com','CSE','789','103','No');

/*Table structure for table `rooms` */

DROP TABLE IF EXISTS `rooms`;

CREATE TABLE `rooms` (
  `roomno` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `strength` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `rooms` */

insert  into `rooms`(`roomno`,`department`,`strength`) values ('101','CSE','25'),('102','CSE','25'),('103','ECE','25'),('104','ECE','25'),('105','IT','25'),('106','IT','25');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `studentname` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `rollno` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `roomno` varchar(100) DEFAULT NULL,
  `facultyname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`studentname`,`password`,`rollno`,`email`,`department`,`roomno`,`facultyname`) values ('ramu','ramu','7894','nikilp306@gmail.com','CSE','101','dileep'),('rahul','rahul','7563','rahul@gmail.com','CSE','101','dileep'),('ramesh','ramesh','1546','ramesh4@gmail.com','ECE','103','praneeth'),('vishnu','vishnu','4563','vishnu@gmail.com','IT','105','nikil'),('kiran','kiran','7415','kiran72gmail.com','CSE','101','dileep'),('santosh','santosh','7896','santosh@gmail.com','CSE','101','dileep'),('madhuri','madhuri','2587','madhuri@gmail..com','CSE','101','dileep'),('mallesh','mallesh','1365','mallesh@gmail.com','CSE','101','dileep'),('monica','monica','9635','monical@gmail.com','CSE','101','dileep'),('aditya','aditya','7569','aditya@gmail.com','CSE','101','dileep'),('hemanth','hemanth','3547','hemanth@gmail.com','CSE','101','dileep'),('suhasini','suhasini','5324','suhasini@gmail.com','CSE','101','dileep'),('kalyani','kalyani','5896','kalyani2gmail.com','CSE','101','dileep'),('kumudini','kumudini','4125','kumudini@gmail.com','CSE','101','dileep'),('likitha','likitha','3333','likitha2gmail.com','CSE','101','dileep'),('praneeth','praneeth','2722','praneeth@gmail.com','CSE','101','dileep'),('sairam','sairam','4141','sairam@gmail.com','CSE','101','dileep'),('srunjay','srunjay','5236','srunjay@gmail.com','CSE','101','dileep'),('sankeerth','sankeerth','7812','sankeerth@gmail.com','CSE','101','dileep'),('abhinesh','abhinesh','9354','abhinesh@gmail.com','CSE','101','dileep'),('krishna','krishna','5678','krishna@gmail.com','CSE','101','dileep'),('gaytari','gayatri','6987','gayatri@gmail.com','CSE','101','dileep'),('shirisha','shirisha','8569','shirisha@gmail.com','CSE','101','dileep'),('vijju','vijju','5732','viJJU2gmail.com','CSE','101','dileep'),('saikiran','saikiran','8529','saikiran@gmail.com','CSE','101','dileep'),('anjali','anjali','4796','anjali@gmail.com','CSE','101','dileep'),('ramya','ramya','2368','ramya@gmail.com','CSE','101','dileep'),('raghu','raghu','1258','raghu@gmail.com','ECE','103','praneeth'),('kamalesh','kamalesh','4792','kamalesh2gmail.com','ECE','103','praneeth'),('poojitha','poojith','3698','poojitha@gmail.com','ECE','103','praneeth'),('aryan','aryan','3247','aryan@gmail.com','ECE','103','praneeth'),('shyam','shyam','3589','shyam@gmail.com','ECE','103','praneeth'),('seetharam','seetharam','3691','seetharam@gmail.com','ECE','103','praneeth'),('manoj','manoj','9635','manoj@gmail.com','ECE','103','praneeth'),('gani','gani','4256','gani@gmail.com','ECE','103','praneeth'),('harsha','harsha','8965','harsha@gmail.com','ECE','103','praneeth'),('vamshi','vamshi','3126','vamshi@gmail.com','ECE','103','praneeth'),('dayakar','dayakar','8962','dayakar@gmail.com','ECE','103','praneeth'),('kalyanii','kalyani','6935','kalyanmi@gmail.com','ECE','103','praneeth'),('shiva','shiva','8964','shiva@gmail.com','ECE','103','praneeth'),('akhil','akhil','5555','akhil@gmail.com','ECE','103','praneeth'),('suhas','suhas','8798','suhas2gmail.com','ECE','103','praneeth'),('Shabareesh','shabareesh','3695','shabareesh@gmail.com','ECE','103','praneeth'),('uday','udat=y','4789','uday@gmail.com','ECE','103','praneeth'),('rakul','rakul','8965','rakul@gmail.com','ECE','103','praneeth'),('samyuktha','samyuktha','2539','samyuktha@gmail.com','ECE','103','praneeth'),('kondal','kondal','4721','kondalreddy2gmail.com','ECE','103','praneeth'),('manasa','manasa','2378','manasa@gmail.com','ECE','103','praneeth'),('abhinav','abhinav','2233','abhinav@gmail.com','ECE','103','praneeth'),('vinay','vinay','9898','vinay@gmail.com','IT','105','nikil'),('bittu','bittu','7854','bittu@gmail.com','IT','105','nikil'),('vibhu','vibhu','3269','vibhu@gmail.com','IT','105','nikil'),('vikas','vikas','5225','vikas@gmail.com','IT','105','nikil'),('siddanth','siddanth','7447','siddanth@gmail.com','IT','105','nikil'),('gowtham','gowtham','9636','gowtham@gmail.com','IT','105','nikil'),('ashish','ashish','8529','ashish@gmail.com','IT','105','nikil'),('miacheal','miacheal','3212','miacheal@gmail.com','IT','105','nikil'),('sanghavi','sanghavi','8899','sanghavi@gmail.com','IT','105','nikil'),('karthick','karthick','8456','karthick@gmail.com','IT','105','nikil'),('bindu','bindu','9999','bindu@gmail.com','IT','105','nikil'),('noel','noel','5555','noel@gmail.com','IT','105','nikil'),('nissar','nissar','7659','nissar@gmail.com','IT','105','nikil'),('koundinya','koundinya','5465','koundinya@gmail.com','IT','105','nikil'),('ramesh','ramesh','7823','ramesh@gmail.com','IT','105','nikil'),('keerthi','keerthi','9898','keerthi@gmail.com','IT','105','nikil'),('sownjanya','sowjanya','2356','sowjanya@gmail.com','IT','105','nikil'),('sowmya','sowmya','7562','sowmya@gmail.com','IT','105','nikil'),('chandu','chandu','4125','chandu@gmail.com','IT','105','nikil'),('maruthi','maruthi','9214','maruthi@gmail.com','IT','105','nikil'),('mukesh','mukesh','7385','mukesh@gmail.com','IT','105','nikil'),('sriram','sriram','8547','sriram@gmail.com','IT','105','nikil'),('praveen','praveen','7766','praveen@gmail.com','IT','105','nikil'),('sravan','sravan','1598','sravan@gmail.com','IT','105','nikil'),('suraj','suraj','8888','suraj@gmail.com','IT','105','nikil'),('aa','aa','8758','aa@gmail.com','ECE','103','praneeth'),('bb','bb','4775','bb@gmail.com','ECE','103','praneeth');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
