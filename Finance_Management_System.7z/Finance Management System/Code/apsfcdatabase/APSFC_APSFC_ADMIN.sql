create table APSFC_ADMIN (USERNAME VARCHAR2(10), PASSWORD VARCHAR2(10))
insert into APSFC_ADMIN (USERNAME,PASSWORD) values('admin','admin')
insert into APSFC_ADMIN (USERNAME,PASSWORD) values('sai','sai')
insert into APSFC_ADMIN (USERNAME,PASSWORD) values('qwert','qwert')
