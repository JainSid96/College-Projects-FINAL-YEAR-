
 
 conn system/system


 create user apsfc identified by apsfc;

 grant dba to apsfc;


conn apsfc/apsfc


drop table apsfc_customer cascade_constraints;

create table apsfc_customer(CUSTOMER_CODE	NUMBER(5) primary key,
CUSTOMER_NAME	VARCHAR2(30),
ORGANIZATION	VARCHAR2(15),
SCALE	VARCHAR2(30),
ANNUAL_TURNOVER	NUMBER(15),
ADDRESS	VARCHAR2(100),
PHONE	VARCHAR2(15),
ZIP	NUMBER(15));

drop table apsfc_cust_loan cascade_constraints;

create table apsfc_cust_loan(LOAN_NUMBER	NUMBER(5) primary key,
CUSTOMER_CODE	NUMBER(5),
LOAN_CODE	NUMBER(5),
INTEREST_CODE	NUMBER(5),
LOAN_AMOUNT	NUMBER(9),
NO_OF_MONTHS	NUMBER(3),
MONTHLY_PAYMENT	NUMBER(6),
LOAN_DATE	DATE,
TOTAL_AMOUNT	NUMBER(10));

drop table apsfc_emp cascade_constraints;
create table apsfc_emp(EMPLOYEE_NO	NUMBER(5) primary key,
EMPLOYEE_NAME	VARCHAR2(15),
DESIGNATION	VARCHAR2(15),
SALARY	NUMBER(6),
ADDRESS	VARCHAR2(20),
PHONE	VARCHAR2(7));

drop table apsfc_int cascade_constraints;
create table apsfc_int(GROUP_NAME VARCHAR2(20),INTEREST_CODE	NUMBER (5) primary key,
INTEREST_RATE	NUMBER (4, 2));

drop table apsfc_loan_mstr cascade_constraints;
create table apsfc_loan_mstr(LOAN_CODE	NUMBER(5) primary key,
LOAN_DESCRIPTION	VARCHAR2 (30));

drop table apsfc_users cascade_constraints;
create table apsfc_users(USER_ID	VARCHAR2 (10) primary key,
PASSWORD VARCHAR2 (10),uname VARCHAR2 (10),age VARCHAR2 (10),sex VARCHAR2 (10),address VARCHAR2 (10),annual VARCHAR2 (10),scale VARCHAR2 (10),state varchar2(10));

drop table apsfc_payment cascade_constraints;
create table apsfc_payment(PAYMENT_ID	NUMBER (5) primary key,
LOAN_NO	NUMBER (5),
PAYMENT_AMOUNT	NUMBER (6),
PAYMENT_DATE	DATE,
RECEIVED_BY	NUMBER(5),
DD_NO	NUMBER(6));

create table apsfc_admin(username varchar2(15)UNIQUE,password varchar2(15));

INSERT INTO APSFC_admin VALUES('admin','admin');

commit;
set autocommit on;