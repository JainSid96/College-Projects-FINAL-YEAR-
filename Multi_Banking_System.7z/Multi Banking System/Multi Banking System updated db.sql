/*
SQLyog Community Edition- MySQL GUI v7.15 
MySQL - 5.5.29 : Database - bank
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`bank` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bank`;

/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `ID` int(11) DEFAULT NULL,
  `BNAME` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `bank` */

/*Table structure for table `blogin` */

DROP TABLE IF EXISTS `blogin`;

CREATE TABLE `blogin` (
  `ID` int(11) DEFAULT NULL,
  `BID` varchar(100) DEFAULT NULL,
  `PWD` varchar(100) DEFAULT NULL,
  `BNAME` varchar(100) DEFAULT NULL,
  `STATUS` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `blogin` */

/*Table structure for table `clogin` */

DROP TABLE IF EXISTS `clogin`;

CREATE TABLE `clogin` (
  `ID` int(11) DEFAULT NULL,
  `CID` varchar(100) DEFAULT NULL,
  `PWD` varchar(100) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `clogin` */

/*Table structure for table `creject` */

DROP TABLE IF EXISTS `creject`;

CREATE TABLE `creject` (
  `CID` varchar(100) DEFAULT NULL,
  `PWD` varchar(100) DEFAULT NULL,
  `ACCNO` varchar(100) DEFAULT NULL,
  `BNAME` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `creject` */

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `ID` varchar(100) DEFAULT NULL,
  `CID` varchar(100) DEFAULT NULL,
  `PWD` varchar(100) DEFAULT NULL,
  `ACCNO` varchar(100) DEFAULT NULL,
  `ATYPE` varchar(100) DEFAULT NULL,
  `CNAME` varchar(100) DEFAULT NULL,
  `BNAME` varchar(100) DEFAULT NULL,
  `BAL` int(11) DEFAULT NULL,
  `TPWD` varchar(100) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

/*Table structure for table `reject` */

DROP TABLE IF EXISTS `reject`;

CREATE TABLE `reject` (
  `CID` varchar(100) DEFAULT NULL,
  `ACCNO` varchar(100) DEFAULT NULL,
  `ATYPE` varchar(100) DEFAULT NULL,
  `BNAME` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `reject` */

/*Table structure for table `taccept` */

DROP TABLE IF EXISTS `taccept`;

CREATE TABLE `taccept` (
  `SCID` varchar(100) DEFAULT NULL,
  `SACCNO` varchar(100) DEFAULT NULL,
  `ATYPE` varchar(100) DEFAULT NULL,
  `SBNAME` varchar(100) DEFAULT NULL,
  `SBAL` int(11) DEFAULT NULL,
  `DCID` varchar(100) DEFAULT NULL,
  `DACCNO` varchar(100) DEFAULT NULL,
  `DTYPE` varchar(100) DEFAULT NULL,
  `DBNAME` varchar(100) DEFAULT NULL,
  `DBAL` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `taccept` */

/*Table structure for table `transfer` */

DROP TABLE IF EXISTS `transfer`;

CREATE TABLE `transfer` (
  `ID` varchar(100) DEFAULT NULL,
  `SACCNO` varchar(100) DEFAULT NULL,
  `DACCNO` varchar(100) DEFAULT NULL,
  `AMT` int(11) DEFAULT NULL,
  `ATYPE` varchar(100) DEFAULT NULL,
  `DTYPE` varchar(100) DEFAULT NULL,
  `TPWD` varchar(100) DEFAULT NULL,
  `SBANK` varchar(100) DEFAULT NULL,
  `DBANK` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transfer` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
