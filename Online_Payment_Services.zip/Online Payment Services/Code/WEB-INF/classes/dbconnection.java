package active;
import java.io.*;
import java.sql.*;

public class dbconnection
{
	public void getconnection()
	{
		try
		{
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:project","payroll","payroll");
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  			Connection con=DriverManager.getConnection("jdbc:odbc:payroll","payroll","payroll");

		}
		catch(SQLException s)
		{
			s.printStackTrace();
			System.out.println(s);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
	
