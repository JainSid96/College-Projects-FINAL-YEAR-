package active;
import active.dbconnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class deductions extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		try
		{
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:project","payroll","payroll");

			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:payroll","payroll","payroll");

			System.out.println("dbconnection");
			res.setContentType("Text/html");
			PrintWriter pw=res.getWriter();
			int year=Integer.parseInt(req.getParameter("year"));
			int month=Integer.parseInt(req.getParameter("month"));
			String empid=req.getParameter("empid");
			System.out.println(empid);
			String empname=req.getParameter("empname");
			System.out.println(empname);
			String deptcode=req.getParameter("deptcode");
			String desncode=req.getParameter("desncode");
			int oe1=Integer.parseInt(req.getParameter("oe1"));
			int oe2=Integer.parseInt(req.getParameter("oe2"));
			int it=Integer.parseInt(req.getParameter("it"));
			int od1=Integer.parseInt(req.getParameter("od1"));
			int od2=Integer.parseInt(req.getParameter("od2"));
			int od3=Integer.parseInt(req.getParameter("od3"));
			PreparedStatement pst=con.prepareStatement("insert into deductions values(?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setInt(1,year);
			pst.setInt(2,month);
			pst.setString(3,empid);
			pst.setString(4,empname);
			pst.setString(5,deptcode);
			pst.setString(6,desncode);
			pst.setInt(7,oe1);
			pst.setInt(8,oe2);
			pst.setInt(9,it);
			pst.setInt(10,od1);
			pst.setInt(11,od2);
			pst.setInt(12,od3);
			pst.executeUpdate();
			System.out.println("record inserted");
			pw.println("data inserted");
			pw.println("<hr><center><a href='./home.jsp'>BACK</a></center>");
		}
		catch(SQLException s)
		{
			s.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
	