package active;
import active.dbconnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class employee extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		try
		{
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:project","payroll","payroll");


			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  			Connection con=DriverManager.getConnection("jdbc:odbc:payroll","payroll","payroll");

			System.out.println("dbconnection");
			res.setContentType("Text/html");
			PrintWriter pw=res.getWriter();
			String empid=req.getParameter("empid");
			String empname=req.getParameter("empname");
			String jdate=req.getParameter("jdate");
			String dob=req.getParameter("dob");
			String address=req.getParameter("address");
			String desn=req.getParameter("desn");
			String grade=req.getParameter("grade");
			String dept=req.getParameter("dept");
			String sal=req.getParameter("salary");
			String pfn=req.getParameter("pfnumber");
			
                                                      if(sal.equals("")||pfn.equals(""))
			{	
				RequestDispatcher dis=req.getRequestDispatcher("./employee.jsp");
				dis.include(req,res);
				pw.println("Plz.. enter all fields");
			}
			else
			{
			int salary=Integer.parseInt(sal);
			String pfindicator=req.getParameter("pfindicator");
			int pfnumber=Integer.parseInt(pfn);
			int cleaves=Integer.parseInt(req.getParameter("cleaves"));
			int eleaves=Integer.parseInt(req.getParameter("eleaves"));
			int sleaves=Integer.parseInt(req.getParameter("sleaves"));
			PreparedStatement pst=con.prepareStatement("insert into employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1,empid);
			pst.setString(2,empname);
			pst.setString(3,jdate);
			pst.setString(4,dob);
			pst.setString(5,address);
			pst.setString(6,desn);
			pst.setString(7,grade);
			pst.setString(8,dept);
			pst.setInt(9,salary);
			pst.setString(10,pfindicator);
			pst.setInt(11,pfnumber);
			pst.setInt(12,cleaves);
			pst.setInt(13,eleaves);
			pst.setInt(14,sleaves);
			pst.executeUpdate();
			System.out.println("record inserted");
			pw.println("data inserted");
			pw.println("<hr><center><a href='./home.jsp'>BACK</a></center>");
			}
		}
		catch(SQLException s)
		{
			s.printStackTrace();
			System.out.println(s);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
	